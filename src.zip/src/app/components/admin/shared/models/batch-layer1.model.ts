export interface BatchLayer1Data {
  id: string;
  batchCode: string;
  batchName: string;
  batchStartDate: string;
}
