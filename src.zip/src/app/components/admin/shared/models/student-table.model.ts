export interface StudentTableData {
  id: string;
  studentCode: string;
  studentName: string;
  emailID: string;
}
