export interface TeachersTableData {
  id: string;
  teacherName: string;
  courseAssigned: string[];
  emailID: string;
}
