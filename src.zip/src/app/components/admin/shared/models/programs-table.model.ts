export interface ProgramsTable {
  code: string;
  programName: string;
  theoryTime: string;
  practiceTime: string;
  description: string;
  courses: string;
}
