export interface TableData {
  id: string;
  code: string;
  course: string;
  theoryTime: string;
  practiceTime: string;
  description: string;
  addTopics: string;
}
