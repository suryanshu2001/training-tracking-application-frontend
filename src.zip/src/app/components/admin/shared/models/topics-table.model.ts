export interface TopicsData {
  id: string;
  order: string;
  topicName: string;
  theoryTime: string;
  practiceTime: string;
  summary: string;
  content: string;
}
