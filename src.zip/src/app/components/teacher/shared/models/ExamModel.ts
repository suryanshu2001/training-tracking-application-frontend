export interface ExamModel {
  examName: string;
  totalMarks: number;
  examDate: string;
  examTime: string;
  uploadFile: string;
}
